const fetch = require('node-fetch');

module.exports = async (req, res) => {
  // Add CORS headers
  res.setHeader('Access-Control-Allow-Origin', 'https://dolphin-store-20230509.myshopify.com'); // allow Shopify
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { address } = req.body;
  if (!address || !address.trim()) {
    return res.status(400).json({ error: 'Address missing' });
  }

  // Dolphin credentials
  const username = 'client_hy4kcyqls6xp';
  const password = 'Zde02cfBnYsIwsgddlk6jiiYxMxO0Cw0';
  const authHeader = 'Basic ' + Buffer.from(`${username}:${password}`).toString('base64');

  try {
    const response = await fetch(
      'https://dolphin-telecoms-coverage-map-api.lionafricadigital.com/api/external/coverage/validate',
      {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': authHeader
        },
        body: JSON.stringify({ address, service_use: "Home" })
      }
    );

    const text = await response.text();
    try {
      const data = JSON.parse(text);
      return res.status(200).json(data);
    } catch {
      return res.status(200).send(text);
    }
  } catch (err) {
    console.error("Vercel proxy error:", err);
    return res.status(500).json({ error: 'Could not validate coverage. Try again.' });
  }
};